// src/pages/MaquinasLayout.jsx
import React from 'react';
import { Outlet } from 'react-router-dom';

const MaquinasLayout = () => {
  return <Outlet />;
};

export default MaquinasLayout;